from django.contrib import admin
from import_export.admin import ImportExportModelAdmin

 # Register your models here.
from .models import Espetaculos
from .models import Professor
from .models import Aluno
from .models import Tipodanca
from .models import Estudios

admin.site.register(Espetaculos)
admin.site.register(Professor)
admin.site.register(Aluno)
admin.site.register(Tipodanca)
admin.site.register(Estudios)
