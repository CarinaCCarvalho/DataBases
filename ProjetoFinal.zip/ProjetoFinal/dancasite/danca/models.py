from django.db import models

class Espetaculos(models.Model):
    nome = models.CharField(max_length=200, null=False, blank=False)
    sitio = models.CharField(max_length=200, null=True, blank=True)
    duracaomin = models.IntegerField(null=True, blank=True)
    nrdancas = models.IntegerField(null=True, blank=True)
    def __str__(self):
        return self.nome


class Professor(models.Model):
    espetaculos = models.ForeignKey(Espetaculos, on_delete=models.CASCADE)
    nome = models.CharField(max_length = 200, null=False, blank=False)
    datanasc = models.IntegerField(null=True, blank=True)
    nacionalidade = models.CharField(max_length=200, null=True, blank=True)
    def __str__(self):
        return self.nome+"-"+self.espetaculos.nome


class Estudios(models.Model):
    nome = models.CharField(max_length=200, null=False, blank=False)
    capacidade = models.IntegerField(null=True, blank=True)
    def __str__(self):
        return self.nome


class Tipodanca(models.Model):
    professor = models.ForeignKey(Professor, on_delete=models.CASCADE)
    estudios = models.ForeignKey(Estudios, on_delete=models.CASCADE, null=True, blank=True)
    nome = models.CharField(max_length=200, null=False, blank=False)
    graudificuldade = models.IntegerField(null=True, blank=True)
    horas = models.IntegerField(null=True, blank=True)
    def __str__(self):
        return self.nome+"-"+self.professor.nome


class Aluno(models.Model):
    espetaculos = models.ForeignKey(Espetaculos, on_delete=models.CASCADE)
    tipodanca = models.ForeignKey(Tipodanca, on_delete=models.CASCADE, null=True, blank=True)
    nome = models.CharField(max_length=200, null=False, blank=False)
    datanasc = models.IntegerField(null=True, blank=True)
    grau = models.IntegerField(null=True, blank=True)
    horasemanais = models.IntegerField(null=True, blank=True)
    numaulas = models.IntegerField(null=True, blank=True)
    def __str__(self):
        return self.nome+"-"+self.tipodanca.nome
