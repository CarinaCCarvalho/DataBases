insert into "danca_espetaculos" (nome, sitio, duracaomin, nrdancas)
values
('Lago dos Cisnes', 'TAGV', 180, 28),
('Bela Adormecida', 'TAGV', 120, 25),
('Quebra-Nozes', 'Convento São Francisco', 120, 18);

insert into "danca_estudios" (nome, capacidade)
values
('Estudio A', 70),
('Estudio B', 60),
('Estudio C', 20),
('Estudio D', 80),
('Estudio E', 30);

insert into "danca_professor" (espetaculos_id, nome, datanasc, nacionalidade)
values
((select id from "danca_espetaculos" where nome = 'Lago dos Cisnes'), 'Nádia Costa', 1980, 'brasileira'),
((select id from "danca_espetaculos" where nome = 'Bela Adormecida'), 'Gilberto Fernandes', 1970, 'portugues'),
((select id from "danca_espetaculos" where nome = 'Quebra-Nozes'), 'Esilda Martins', 1984, 'brasileira'),
((select id from "danca_espetaculos" where nome = 'Lago dos Cisnes'), 'Marta Serra', 1990, 'portuguesa'),
((select id from "danca_espetaculos" where nome = 'Bela Adormecida'), 'Antonio Rocha', 1985, 'portugues'),
((select id from "danca_espetaculos" where nome = 'Quebra-Nozes'), 'Amilcar Costa', 1980, 'portugues');

insert into "danca_tipodanca" (estudios_id, professor_id, nome, graudificuldade, horas)
values
(
	(select id from "danca_estudios" where nome='Estudio A'),
        (select id from "danca_professor" where nome='Nádia Costa'), 
	'Ballet', 4, 4
),
(	(select id from "danca_estudios" where nome='Estudio B'),
        (select id from "danca_professor" where nome='Nádia Costa'), 
	'Samba', 5, 1
),
(
	(select id from "danca_estudios" where nome='Estudio B'),
        (select id from "danca_professor" where nome='Marta Serra'), 
	'Reportório Clássico', 5, 2
),
(
	(select id from "danca_estudios" where nome='Estudio C'),
        (select id from "danca_professor" where nome='Gilberto Fernandes'), 
	'Contemporânea', 7, 1
),
(
	(select id from "danca_estudios" where nome='Estudio D'),
        (select id from "danca_professor" where nome='Esilda Martins'), 
	'Hip Hop', 3, 1
),
(
	(select id from "danca_estudios" where nome='Estudio E'),
        (select id from "danca_professor" where nome='Antonio Rocha'), 
	'Sapateado', 4, 1
),
(
	(select id from "danca_estudios" where nome='Estudio E'),
        (select id from "danca_professor" where nome='Amilcar Costa'), 
	'Tango', 4, 1
);

insert into "danca_aluno" (espetaculos_id, tipodanca_id, nome, datanasc, grau, horasemanais, numaulas)
values
(
	(select id from "danca_espetaculos" where nome='Lago dos Cisnes'),
	(select id from "danca_tipodanca" where nome='Ballet'),
	'Inês Mariz', 2001, 6, 4, 2		
),
(
	(select id from "danca_espetaculos" where nome='Bela Adormecida'),
	(select id from "danca_tipodanca" where nome='sapateado'),
	'Mariana Silva', 2001, 5, 3, 3
),
(
	(select id from "danca_espetaculos" where nome='Quebra-Nozes'),
	(select id from "danca_tipodanca" where nome='Tango'),
	'Paula Andrade', 2001, 3, 4, 4	
),
(
	(select id from "danca_espetaculos" where nome='Lago dos Cisnes'),
	(select id from "danca_tipodanca" where nome='Reportório Clássico'),
	'Diana Costa', 2001, 4, 4, 2
),
(
	(select id from "danca_espetaculos" where nome='Bela Adormecida'),
	(select id from "danca_tipodanca" where nome='Samba'),
	'Rita Simões', 2001, 7, 3, 3
),
(
	(select id from "danca_espetaculos" where nome='Quebra-Nozes'),
	(select id from "danca_tipodanca" where nome='Contemporânea'),
	'Pedro Serra', 2001, 6, 5, 5
),
(
	(select id from "danca_espetaculos" where nome='Lago dos Cisnes'),
	(select id from "danca_tipodanca" where nome='Hip Hop'),
	'Maria Lopes', 2001, 8, 4, 2
),
(
	(select id from "danca_espetaculos" where nome='Bela Adormecida'),
	(select id from "danca_tipodanca" where nome='Tango'),
	'Carina Carvalho', 2001, 4, 3, 3
),
(
	(select id from "danca_espetaculos" where nome='Quebra-Nozes'),
	(select id from "danca_tipodanca" where nome='Contemporânea'),
	'Margarida Biscaia', 2001, 5, 4, 2
);
