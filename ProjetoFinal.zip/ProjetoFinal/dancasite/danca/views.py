from django.http import HttpResponse
from django.shortcuts import render
from django.template import loader

from .models import Espetaculos
from .models import Professor
from .models import Aluno
from .models import Tipodanca
from .models import Estudios

def index(request):
    template = loader.get_template('danca/index.html')
    context = {
        'numEspetaculoss':Espetaculos.objects.all().count(),
        'numProfessors':Professor.objects.all().count(),
        'numAlunos':Aluno.objects.all().count(),
        'numTipodancas':Tipodanca.objects.all().count(),
        'numEstudioss':Estudios.objects.all().count(),
    }
    return HttpResponse(template.render(context, request))

def Espetaculoss(request):
    template = loader.get_template('danca/espetaculoss.html')
    items = Espetaculos.objects.order_by('nome')[0:]
    context = {
        'espetaculoss':items
    }
    return HttpResponse(template.render(context, request))

def EspetaculosDetails(request, espetaculos_id):
    template = loader.get_template('danca/espetaculosDetails.html')
    try:
        myEspetaculos = Espetaculos.objects.get(pk = espetaculos_id)
        context = {'espetaculos' : myEspetaculos}
    except Espetaculos.DoesNotExist:
        raise Http404("Espetaculos does not exist")

    return HttpResponse(template.render(context, request))

def Estudioss(request):
    template = loader.get_template('danca/estudioss.html')
    items = Estudios.objects.order_by('nome')[0:]
    context = {
        'estudioss':items
    }
    return HttpResponse(template.render(context, request))

def EstudiosDetails(request, estudios_id):
    template = loader.get_template('danca/estudiosDetails.html')
    try:
        myEstudios = Estudios.objects.get(pk = estudios_id)
        context = {'estudios' : myEstudios}
    except Estudios.DoesNotExist:
        raise Http404("Estudios does not exist")

    return HttpResponse(template.render(context, request))

def Professors(request):
    template = loader.get_template('danca/professors.html')
    items = Professor.objects.order_by('nome')[0:]
    context = {
        'professors':items
    }
    return HttpResponse(template.render(context, request))

def ProfessorDetails(request, professor_id):
    template = loader.get_template('danca/professorDetails.html')
    try:
        myProfessor = Professor.objects.get(pk = professor_id)
        context = {'professor' : myProfessor}
    except Professor.DoesNotExist:
        raise Http404("Professor does not exist")

    return HttpResponse(template.render(context, request))


def Tipodancas(request):
    template = loader.get_template('danca/tipodancas.html')
    items = Tipodanca.objects.order_by('nome')[0:]
    context = {
        'tipodancas':items
    }
    return HttpResponse(template.render(context, request))

def TipodancaDetails(request, tipodanca_id):
    template = loader.get_template('danca/tipodancaDetails.html')
    try:
        myTipodanca = Tipodanca.objects.get(pk = tipodanca_id)
        context = {'tipodanca' : myTipodanca}
    except Tipodanca.DoesNotExist:
        raise Http404("Tipoanca does not exist")

    return HttpResponse(template.render(context, request))

def Alunos(request):
    template = loader.get_template('danca/alunos.html')
    items = Aluno.objects.order_by('nome')[0:]
    context = {
        'alunos':items
    }
    return HttpResponse(template.render(context, request))

def AlunoDetails(request, aluno_id):
    template = loader.get_template('danca/alunoDetails.html')
    try:
        myAluno = Aluno.objects.get(pk = aluno_id)
        context = {'aluno' : myAluno}
    except Aluno.DoesNotExist:
        raise Http404("Aluno does not exist")

    return HttpResponse(template.render(context, request))
