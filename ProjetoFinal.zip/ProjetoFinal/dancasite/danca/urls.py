from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),

     #Espetaculos
    path('espetaculoss', views.Espetaculoss, name='espetaculoss'),
    path('espetaculoss/<int:espetaculos_id>/', views.EspetaculosDetails, name='espetaculosDetails'),

    #Estudios
    path('estudioss', views.Estudioss, name='estudioss'),
    path('estudioss/<int:estudios_id>/', views.EstudiosDetails, name='estudiosDetails'),

    #Professor
    path('professors', views.Professors, name='professors'),
    path('professors/<int:professor_id>/', views.ProfessorDetails, name='professorDetails'),

    #Tipodanca
    path('tipodancas', views.Tipodancas, name='tipodancas'),
    path('tipodancas/<int:tipodanca_id>/', views.TipodancaDetails, name='tipodancaDetails'),

    #Aluno
    path('alunos', views.Alunos, name='alunos'),
    path('alunos/<int:aluno_id>/', views.AlunoDetails, name='alunoDetails'),

    ]